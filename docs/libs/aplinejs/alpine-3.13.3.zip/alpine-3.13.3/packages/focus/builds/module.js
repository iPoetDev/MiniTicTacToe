import registerFocusPlugin from '../src/index.js'

export default registerFocusPlugin
