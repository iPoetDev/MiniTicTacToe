---
order: 6
title: Globals
font-type: mono
prefix: Alpine.
type: sub-directory
---
