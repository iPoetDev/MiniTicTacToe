---
order: 5
title: Magics
prefix: $
font-type: mono
type: sub-directory
---
