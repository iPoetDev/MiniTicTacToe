import collapse from '../src/index.js'

export default collapse
