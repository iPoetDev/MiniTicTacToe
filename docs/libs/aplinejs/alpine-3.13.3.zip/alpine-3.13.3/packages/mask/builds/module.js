import maskPlugin, { stripDown } from '../src/index.js'

export default maskPlugin

export { stripDown }
