import { morph } from './morph'

export default function (Alpine) {
    Alpine.morph = morph
}

export { morph }
