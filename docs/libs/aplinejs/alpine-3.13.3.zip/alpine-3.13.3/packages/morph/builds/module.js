import morphPlugin, { morph } from '../src/index.js'

export default morphPlugin

export { morph }
