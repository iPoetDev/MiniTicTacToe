import persist from '../src/index.js'

export default persist
