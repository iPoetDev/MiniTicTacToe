
export function warn(message, ...args) {
    console.warn(`Alpine Warning: ${message}`, ...args)
}
